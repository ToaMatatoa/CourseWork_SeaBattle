﻿namespace SeaBattleNextGen
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelSeveral = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelHelper = new System.Windows.Forms.Panel();
            this.panelX3 = new System.Windows.Forms.Panel();
            this.panelX0 = new System.Windows.Forms.Panel();
            this.panelX2 = new System.Windows.Forms.Panel();
            this.panelX1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelEnemy = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panelStatus = new System.Windows.Forms.Panel();
            this.statusLabel = new System.Windows.Forms.Label();
            this.hidePanel = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.panelSeveral.SuspendLayout();
            this.panelHelper.SuspendLayout();
            this.panelEnemy.SuspendLayout();
            this.hidePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSeveral
            // 
            this.panelSeveral.Controls.Add(this.label31);
            this.panelSeveral.Controls.Add(this.label30);
            this.panelSeveral.Controls.Add(this.label29);
            this.panelSeveral.Controls.Add(this.label28);
            this.panelSeveral.Controls.Add(this.label27);
            this.panelSeveral.Controls.Add(this.label26);
            this.panelSeveral.Controls.Add(this.label25);
            this.panelSeveral.Controls.Add(this.label24);
            this.panelSeveral.Controls.Add(this.label23);
            this.panelSeveral.Controls.Add(this.label12);
            this.panelSeveral.Controls.Add(this.label11);
            this.panelSeveral.Controls.Add(this.label10);
            this.panelSeveral.Controls.Add(this.label9);
            this.panelSeveral.Controls.Add(this.label8);
            this.panelSeveral.Controls.Add(this.label7);
            this.panelSeveral.Controls.Add(this.label6);
            this.panelSeveral.Controls.Add(this.label5);
            this.panelSeveral.Controls.Add(this.label4);
            this.panelSeveral.Controls.Add(this.label3);
            this.panelSeveral.Controls.Add(this.label2);
            this.panelSeveral.Location = new System.Drawing.Point(13, 43);
            this.panelSeveral.Name = "panelSeveral";
            this.panelSeveral.Size = new System.Drawing.Size(275, 275);
            this.panelSeveral.TabIndex = 0;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(4, 256);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(25, 19);
            this.label31.TabIndex = 26;
            this.label31.Text = "10";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(10, 231);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(17, 19);
            this.label30.TabIndex = 25;
            this.label30.Text = "9";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(10, 206);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(17, 19);
            this.label29.TabIndex = 24;
            this.label29.Text = "8";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(10, 181);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(17, 19);
            this.label28.TabIndex = 23;
            this.label28.Text = "7";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(10, 156);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(17, 19);
            this.label27.TabIndex = 22;
            this.label27.Text = "6";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 131);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(17, 19);
            this.label26.TabIndex = 21;
            this.label26.Text = "5";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(10, 106);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(17, 19);
            this.label25.TabIndex = 20;
            this.label25.Text = "4";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(10, 81);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(17, 19);
            this.label24.TabIndex = 19;
            this.label24.Text = "3";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 56);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(17, 19);
            this.label23.TabIndex = 18;
            this.label23.Text = "2";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 19);
            this.label12.TabIndex = 17;
            this.label12.Text = "1";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(32, 8);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 19);
            this.label11.TabIndex = 16;
            this.label11.Text = "A";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(232, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 19);
            this.label10.TabIndex = 15;
            this.label10.Text = "I";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(207, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 19);
            this.label9.TabIndex = 14;
            this.label9.Text = "H";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(182, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 19);
            this.label8.TabIndex = 13;
            this.label8.Text = "G";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(157, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 19);
            this.label7.TabIndex = 12;
            this.label7.Text = "F";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(132, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 19);
            this.label6.TabIndex = 11;
            this.label6.Text = "E";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(107, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 19);
            this.label5.TabIndex = 10;
            this.label5.Text = "D";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(82, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 19);
            this.label4.TabIndex = 9;
            this.label4.Text = "C";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 19);
            this.label3.TabIndex = 8;
            this.label3.Text = "B";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(257, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 19);
            this.label2.TabIndex = 7;
            this.label2.Text = "J";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelHelper
            // 
            this.panelHelper.Controls.Add(this.panelX3);
            this.panelHelper.Controls.Add(this.panelX0);
            this.panelHelper.Controls.Add(this.panelX2);
            this.panelHelper.Controls.Add(this.panelX1);
            this.panelHelper.Controls.Add(this.label1);
            this.panelHelper.Location = new System.Drawing.Point(13, 12);
            this.panelHelper.Name = "panelHelper";
            this.panelHelper.Size = new System.Drawing.Size(275, 25);
            this.panelHelper.TabIndex = 1;
            // 
            // panelX3
            // 
            this.panelX3.BackColor = System.Drawing.Color.SaddleBrown;
            this.panelX3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelX3.Location = new System.Drawing.Point(250, 0);
            this.panelX3.Margin = new System.Windows.Forms.Padding(0);
            this.panelX3.Name = "panelX3";
            this.panelX3.Size = new System.Drawing.Size(25, 25);
            this.panelX3.TabIndex = 6;
            // 
            // panelX0
            // 
            this.panelX0.BackColor = System.Drawing.Color.SaddleBrown;
            this.panelX0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelX0.Location = new System.Drawing.Point(175, 0);
            this.panelX0.Margin = new System.Windows.Forms.Padding(0);
            this.panelX0.Name = "panelX0";
            this.panelX0.Size = new System.Drawing.Size(25, 25);
            this.panelX0.TabIndex = 5;
            // 
            // panelX2
            // 
            this.panelX2.BackColor = System.Drawing.Color.SaddleBrown;
            this.panelX2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelX2.Location = new System.Drawing.Point(225, 0);
            this.panelX2.Margin = new System.Windows.Forms.Padding(0);
            this.panelX2.Name = "panelX2";
            this.panelX2.Size = new System.Drawing.Size(25, 25);
            this.panelX2.TabIndex = 4;
            // 
            // panelX1
            // 
            this.panelX1.BackColor = System.Drawing.Color.SaddleBrown;
            this.panelX1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelX1.Location = new System.Drawing.Point(200, 0);
            this.panelX1.Margin = new System.Windows.Forms.Padding(0);
            this.panelX1.Name = "panelX1";
            this.panelX1.Size = new System.Drawing.Size(25, 25);
            this.panelX1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Расположите корабль";
            // 
            // panelEnemy
            // 
            this.panelEnemy.Controls.Add(this.label32);
            this.panelEnemy.Controls.Add(this.label33);
            this.panelEnemy.Controls.Add(this.label34);
            this.panelEnemy.Controls.Add(this.label35);
            this.panelEnemy.Controls.Add(this.label36);
            this.panelEnemy.Controls.Add(this.label37);
            this.panelEnemy.Controls.Add(this.label38);
            this.panelEnemy.Controls.Add(this.label39);
            this.panelEnemy.Controls.Add(this.label40);
            this.panelEnemy.Controls.Add(this.label41);
            this.panelEnemy.Controls.Add(this.label13);
            this.panelEnemy.Controls.Add(this.label14);
            this.panelEnemy.Controls.Add(this.label15);
            this.panelEnemy.Controls.Add(this.label16);
            this.panelEnemy.Controls.Add(this.label17);
            this.panelEnemy.Controls.Add(this.label18);
            this.panelEnemy.Controls.Add(this.label19);
            this.panelEnemy.Controls.Add(this.label20);
            this.panelEnemy.Controls.Add(this.label21);
            this.panelEnemy.Controls.Add(this.label22);
            this.panelEnemy.Location = new System.Drawing.Point(313, 43);
            this.panelEnemy.Name = "panelEnemy";
            this.panelEnemy.Size = new System.Drawing.Size(275, 275);
            this.panelEnemy.TabIndex = 1;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(4, 256);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(25, 19);
            this.label32.TabIndex = 36;
            this.label32.Text = "10";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(10, 231);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(17, 19);
            this.label33.TabIndex = 35;
            this.label33.Text = "9";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(10, 206);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(17, 19);
            this.label34.TabIndex = 34;
            this.label34.Text = "8";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(10, 181);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(17, 19);
            this.label35.TabIndex = 33;
            this.label35.Text = "7";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(10, 156);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(17, 19);
            this.label36.TabIndex = 32;
            this.label36.Text = "6";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(10, 131);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(17, 19);
            this.label37.TabIndex = 31;
            this.label37.Text = "5";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(10, 106);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(17, 19);
            this.label38.TabIndex = 30;
            this.label38.Text = "4";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(10, 81);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(17, 19);
            this.label39.TabIndex = 29;
            this.label39.Text = "3";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(10, 56);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(17, 19);
            this.label40.TabIndex = 28;
            this.label40.Text = "2";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(10, 31);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(17, 19);
            this.label41.TabIndex = 27;
            this.label41.Text = "1";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 19);
            this.label13.TabIndex = 26;
            this.label13.Text = "A";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(232, 8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 19);
            this.label14.TabIndex = 25;
            this.label14.Text = "I";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(207, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(19, 19);
            this.label15.TabIndex = 24;
            this.label15.Text = "H";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(182, 8);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(19, 19);
            this.label16.TabIndex = 23;
            this.label16.Text = "G";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(157, 8);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(16, 19);
            this.label17.TabIndex = 22;
            this.label17.Text = "F";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(132, 8);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(16, 19);
            this.label18.TabIndex = 21;
            this.label18.Text = "E";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(107, 8);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(19, 19);
            this.label19.TabIndex = 20;
            this.label19.Text = "D";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(82, 8);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(18, 19);
            this.label20.TabIndex = 19;
            this.label20.Text = "C";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(57, 8);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(17, 19);
            this.label21.TabIndex = 18;
            this.label21.Text = "B";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(257, 8);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(14, 19);
            this.label22.TabIndex = 17;
            this.label22.Text = "J";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelStatus
            // 
            this.panelStatus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelStatus.Location = new System.Drawing.Point(313, 12);
            this.panelStatus.Name = "panelStatus";
            this.panelStatus.Size = new System.Drawing.Size(25, 25);
            this.panelStatus.TabIndex = 2;
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(345, 18);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(0, 19);
            this.statusLabel.TabIndex = 3;
            // 
            // hidePanel
            // 
            this.hidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.hidePanel.Controls.Add(this.label42);
            this.hidePanel.Location = new System.Drawing.Point(9, 12);
            this.hidePanel.Name = "hidePanel";
            this.hidePanel.Size = new System.Drawing.Size(288, 307);
            this.hidePanel.TabIndex = 37;
            this.hidePanel.Visible = false;
            // 
            // label42
            // 
            this.label42.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.label42.Location = new System.Drawing.Point(86, 112);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(106, 75);
            this.label42.TabIndex = 19;
            this.label42.Text = "Ход противника";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(602, 331);
            this.Controls.Add(this.hidePanel);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.panelStatus);
            this.Controls.Add(this.panelEnemy);
            this.Controls.Add(this.panelHelper);
            this.Controls.Add(this.panelSeveral);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "SeaBattle";
            this.panelSeveral.ResumeLayout(false);
            this.panelSeveral.PerformLayout();
            this.panelHelper.ResumeLayout(false);
            this.panelHelper.PerformLayout();
            this.panelEnemy.ResumeLayout(false);
            this.panelEnemy.PerformLayout();
            this.hidePanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelSeveral;
        private System.Windows.Forms.Panel panelHelper;
        private System.Windows.Forms.Panel panelX3;
        private System.Windows.Forms.Panel panelX0;
        private System.Windows.Forms.Panel panelX2;
        private System.Windows.Forms.Panel panelX1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelEnemy;
        private System.Windows.Forms.Panel panelStatus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Panel hidePanel;
        private System.Windows.Forms.Label label42;
    }
}

